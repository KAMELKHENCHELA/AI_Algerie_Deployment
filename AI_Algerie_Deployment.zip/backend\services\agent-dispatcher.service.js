import axios from "axios";

class AgentDispatcher {
    constructor() {
        this.agents = [
            { id: 'math-agent', name: 'خبير الرياضيات', type: 'n8n', keywords: ['حساب', 'رياضيات', 'معادلة', 'إحصاء'] },
            { id: 'legal-agent', name: 'المستشار القانوني', type: 'n8n', keywords: ['قانون', 'محكمة', 'دستور', 'عقد'] },
            { id: 'dev-agent', name: 'خبير البرمجة', type: 'n8n', keywords: ['برمجة', 'كود', 'جافاسكريبت', 'بايثون', 'خطأ'] }
        ];
    }

    async getBestAgent(message) {
        const lowerMsg = message.toLowerCase();
        for (const agent of this.agents) {
            if (agent.keywords.some(k => lowerMsg.includes(k))) {
                return agent;
            }
        }
        return null;
    }

    async routeToN8N(agent, message, userId) {
        const webhookUrl = process.env.N8N_WEBHOOK_URL;
        if (!webhookUrl) {
            console.warn("N8N_WEBHOOK_URL not configured, using mock response for agent:", agent.name);
            return `[${agent.name}]: أهلاً بك! لقد استلمت طلبك المتعلق بـ "${message}". أنا في انتظار إعداد الربط البرمجي الكامل للرد عليك بدقة.`;
        }

        try {
            const response = await axios.post(webhookUrl, {
                agentId: agent.id,
                message: message,
                userId: userId
            });
            return response.data.output || response.data.text || JSON.stringify(response.data);
        } catch (error) {
            console.error("N8N Routing Error:", error);
            return null;
        }
    }
}

export default new AgentDispatcher();

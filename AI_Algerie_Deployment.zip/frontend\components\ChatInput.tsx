'use client'

import React from 'react'
import { Mic, Send, Paperclip, X } from 'lucide-react'

interface ChatInputProps {
    input: string
    setInput: (v: string) => void
    onSend: () => void
    onFileSelect: (file: File | null) => void
    selectedFile: File | null
}

const ChatInput = ({ input, setInput, onSend, onFileSelect, selectedFile }: ChatInputProps) => {
    const fileInputRef = React.useRef<HTMLInputElement>(null)

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault()
            onSend()
        }
    }

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            onFileSelect(e.target.files[0])
        }
    }

    return (
        <div className="mt-4 flex flex-col gap-2">
            {selectedFile && (
                <div className="flex items-center gap-2 bg-slate-800/50 self-start px-3 py-1 rounded-full border border-white/5 text-sm text-slate-300">
                    <span className="truncate max-w-[200px]">{selectedFile.name}</span>
                    <button
                        onClick={() => onFileSelect(null)}
                        className="text-slate-500 hover:text-red-400"
                    >
                        <X size={14} />
                    </button>
                </div>
            )}
            <div className="flex items-center gap-3 bg-slate-900/80 border border-white/10 p-2 rounded-2xl">
                <input
                    type="file"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept=".txt,.js,.py,.pdf,.docx,.json"
                />
                <button
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 text-slate-400 hover:text-titan-emerald transition-all"
                >
                    <Paperclip size={22} />
                </button>
                <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="اكتب رسالتك هنا..."
                    rows={1}
                    className="flex-1 bg-transparent border-none outline-none resize-none text-white text-base py-2"
                />
                <button
                    onClick={onSend}
                    className="bg-titan-emerald hover:scale-105 active:scale-95 transition-all p-3 rounded-xl shadow-lg shadow-emerald-500/30"
                >
                    <Send size={20} />
                </button>
            </div>
        </div>
    )
}

export default React.memo(ChatInput)

# 🚀 دليل الإعداد - Titan Enterprise

## المرحلة الأولى: المتطلبات الأساسية

### الخطوة 1️⃣ تثبيت البرامج المطلوبة

```bash
# تحقق من تثبيت Node.js
node --version  # يجب أن تكون >= v20.0.0
npm --version   # يجب أن تكون >= v9.0.0

# إذا لم تكن مثبتة:
# Windows: اذهب إلى https://nodejs.org/
# macOS:   brew install node
# Linux:   sudo apt install nodejs npm
```

### الخطوة 2️⃣ تثبيت Docker (اختياري لكن موصى به)

```bash
# Windows/Mac
# اذهب إلى https://www.docker.com/products/docker-desktop

# Linux
sudo apt-get install docker docker-compose
```

---

## المرحلة الثانية: استنساخ المشروع

```bash
# استنساخ المستودع
git clone https://github.com/your-repo/titan.git
cd titan

# أو إذا استخدمت SSH
git clone git@github.com:your-repo/titan.git
cd titan
```

---

## المرحلة الثالثة: إعداد Backend

### الخطوة 1️⃣ الاعتماديات

```bash
cd backend

# تثبيت الـ dependencies
npm install

# أو إذا استخدمت yarn
yarn install
```

### الخطوة 2️⃣ ملف البيئة

```bash
# انسخ الملف النموذجي
cp .env.example .env

# قم بتحرير .env بـ VS Code
code .env

# أو باستخدام محرر آخر
nano .env  # أو vim .env
```

### الخطوة 3️⃣ إضافة مفاتيح API

في `.env`، استبدل:

```bash
# OpenAI (اختياري لكن موصى)
OPENAI_API_KEY="sk-your-real-key-from-openai"
# احصل على المفتاح من: https://platform.openai.com/api-keys

# DeepSeek (اختياري)
DEEPSEEK_API_KEY="your-deepseek-key-from-deepseek"
# احصل على المفتاح من: https://www.deepseek.com/

# Claude (اختياري)
ANTHROPIC_API_KEY="your-anthropic-key-from-anthropic"
# احصل على المفتاح من: https://www.anthropic.com/
```

### الخطوة 4️⃣ إعداد قاعدة البيانات

```bash
# توليد Prisma Client
npm run db:generate

# تشغيل migrations (التطوير)
npm run db:migrate

# الاختياري: فتح Prisma Studio للتصور
npm run db:studio
```

---

## المرحلة الرابعة: إعداد Frontend

### الخطوة 1️⃣ الاعتماديات

```bash
cd ../frontend

# تثبيت الـ dependencies
npm install
```

### الخطوة 2️⃣ ملف البيئة

```bash
# انسخ الملف النموذجي
cp .env.example .env.local

# قم بتحرير .env.local إذا لزم الأمر
code .env.local
```

**المحتوى الافتراضي يجب أن يكون:**
```bash
NEXT_PUBLIC_API_URL="http://localhost:3000/api"
NEXT_PUBLIC_ENABLE_VOICE_INPUT="true"
NEXT_PUBLIC_ENABLE_STORE="true"
NEXT_PUBLIC_ENABLE_LAB="true"
```

---

## المرحلة الخامسة: التشغيل

### 🔵 الخيار 1: التشغيل المنفصل (للتطوير)

**Terminal 1: Backend**
```bash
cd backend
npm run dev

# ستشاهد:
# 🚀 Titan Enterprise API Gateway running on port 3000
# 🛡️ Rate Limiting enabled (100 req / 15 min)
# 📊 Database connected: file:./dev.db
```

**Terminal 2: Frontend**
```bash
cd frontend
npm run dev

# ستشاهد:
# ▲ Next.js 16.1.6
# - Local: http://localhost:3001
```

### 🟢 الخيار 2: Docker Compose (الموصى به)

```bash
# من المجلد الجذر
docker compose up -d --build

# للتحقق من الحالة
docker compose ps

# لعرض السجلات
docker compose logs -f backend
docker compose logs -f frontend
docker compose logs -f db
```

---

## المرحلة السادسة: التحقق

### ✅ فحص Backend

```bash
# اختبر Health Check
curl http://localhost:3000/health

# يجب أن ترى:
# {"status":"ok","timestamp":"...","environment":"development"}
```

### ✅ فحص Frontend

اذهب إلى: **http://localhost:3001**

يجب أن ترى الواجهة الرئيسية.

### ✅ فحص API

```bash
# اختبر تسجيل جديد
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpass123"
  }'

# يجب أن تحصل على الرد مع token
```

---

## الأوامر المهمة

### Backend

```bash
cd backend

# التطوير
npm run dev          # مع auto-reload

# الإنتاج
npm start

# قاعدة البيانات
npm run db:generate  # توليد Prisma
npm run db:migrate   # تشغيل migrations
npm run db:studio    # الواجهة الرسومية

# الاختبارات
npm test
```

### Frontend

```bash
cd frontend

# التطوير
npm run dev          # مع hot-reload

# البناء
npm run build        # بناء للإنتاج

# الإنتاج
npm start

# الفحص
npm run lint
```

### Docker

```bash
# البناء والتشغيل
docker compose up -d --build

# إيقاف
docker compose down

# حذف الحاويات والأقراص
docker compose down -v

# إعادة بناء
docker compose build

# السجلات
docker compose logs -f service-name
```

---

## استكشاف الأخطاء

### ❌ خطأ: Port already in use

```bash
# على Linux/Mac
lsof -i :3000
kill -9 <PID>

# على Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### ❌ خطأ: Database connection error

```bash
# تأكد من وجود قاعدة البيانات
ls backend/prisma/dev.db

# أو امسح وأعد الإنشاء
rm backend/prisma/dev.db
npm run db:migrate
```

### ❌ خطأ: API key not found

```bash
# تأكد من .env
cat backend/.env

# تأكد من أن المفاتيح موجودة
OPENAI_API_KEY=sk-...
```

### ❌ خطأ: npm modules not found

```bash
# حذف وإعادة تثبيت
rm -rf node_modules package-lock.json
npm install
```

---

## الخطوات التالية

### بعد الإعداد الناجح

1. **استكشف Dashboard**
   - قم بتسجيل حساب جديد
   - بدء محادثة مع الـ AI
   - جرب نماذج مختلفة (GPT, DeepSeek, Claude)

2. **جرب الميزات**
   - اكسب XP عن طريق المحادثات
   - شاهد نظام الإنجازات
   - استكشف المتجر والـ Lab

3. **للتطوير**
   - أضف breakpoints في VS Code
   - استخدم Prisma Studio للبيانات
   - راقب الـ console logs

---

## نصائح للأداء

### للتطوير السريع

```bash
# استخدم nodemon للـ auto-reload
npm run dev

# استخدم Next.js مع fast refresh
npm run dev -- --experimental-app-directory
```

### للاختبار

```bash
# اختبر المحادثات بدون API keys
# ستستخدم البيانات الوهمية (Mock)

# أو أضف مفاتيح حقيقية:
echo 'OPENAI_API_KEY=sk-test-key' >> .env
```

---

## الدعم

إذا واجهت مشكلات:

1. تحقق من الملفات:
   - هل `.env` موجود؟
   - هل `node_modules` مثبت؟

2. اقرأ السجلات:
   ```bash
   # Backend logs
   docker compose logs backend
   
   # أو في Terminal
   npm run dev  # ستشاهد الأخطاء مباشرة
   ```

3. اطلب المساعدة:
   - GitHub Issues
   - Discord Server
   - Email: support@titan.dz

---

**🎉 تم الإعداد بنجاح!**

الآن أنت جاهز للبدء بـ Titan Enterprise!

'use client'

import React from 'react'
import Editor, { loader } from '@monaco-editor/react'

interface CodeEditorProps {
    code: string
    onChange: (value: string | undefined) => void
}

const CodeEditor = ({ code, onChange }: CodeEditorProps) => {
    const handleEditorWillMount = (monaco: any) => {
        monaco.editor.defineTheme('titan-dark', {
            base: 'vs-dark',
            inherit: true,
            rules: [],
            colors: {
                'editor.background': '#020617', // titan-dark
                'editor.lineHighlightBackground': '#10b98110', // titan-emerald/10
            }
        })
    }

    return (
        <div className="h-full w-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
            <Editor
                height="100%"
                defaultLanguage="javascript"
                theme="titan-dark"
                value={code}
                onChange={onChange}
                beforeMount={handleEditorWillMount}
                options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    padding: { top: 20 },
                    fontFamily: "'Fira Code', 'Consolas', monospace",
                    scrollBeyondLastLine: false,
                    automaticLayout: true,
                }}
            />
        </div>
    )
}

export default React.memo(CodeEditor)

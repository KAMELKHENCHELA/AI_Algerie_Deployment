'use client'

import React from 'react'
import { Brain, Zap, Sparkles } from 'lucide-react'

interface ModelSelectorProps {
    selectedModel: 'gpt' | 'deepseek' | 'claude'
    onModelChange: (model: 'gpt' | 'deepseek' | 'claude') => void
}

const ModelSelector = ({ selectedModel, onModelChange }: ModelSelectorProps) => {
    const models = [
        {
            id: 'gpt' as const,
            name: 'GPT-4',
            icon: Brain,
            description: 'OpenAI',
            color: 'from-blue-500 to-blue-600'
        },
        {
            id: 'deepseek' as const,
            name: 'DeepSeek',
            icon: Zap,
            description: 'Deep Reasoning',
            color: 'from-purple-500 to-purple-600'
        },
        {
            id: 'claude' as const,
            name: 'Claude',
            icon: Sparkles,
            description: 'Anthropic',
            color: 'from-amber-500 to-amber-600'
        }
    ]

    return (
        <div className="flex gap-2 mb-4">
            {models.map(model => {
                const Icon = model.icon
                const isSelected = selectedModel === model.id
                return (
                    <button
                        key={model.id}
                        onClick={() => onModelChange(model.id)}
                        className={`
                            flex items-center gap-2 px-4 py-2 rounded-lg font-medium
                            transition-all duration-200 transform
                            ${isSelected
                                ? `bg-gradient-to-r ${model.color} text-white scale-105 shadow-lg shadow-${model.color.split(' ')[1]}/50`
                                : 'bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white'
                            }
                        `}
                        title={model.description}
                    >
                        <Icon size={18} />
                        <span className="text-sm">{model.name}</span>
                    </button>
                )
            })}
        </div>
    )
}

export default React.memo(ModelSelector)

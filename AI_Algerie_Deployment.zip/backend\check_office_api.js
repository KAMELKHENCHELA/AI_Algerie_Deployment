import officeParser from 'officeparser';

async function checkApi() {
    console.log('Checking officeParser API...');
    try {
        const result = officeParser.parseOffice('nonexistent.docx');
        if (result instanceof Promise) {
            console.log('✅ officeParser.parseOffice returns a Promise.');
            try {
                await result;
            } catch (e) {
                console.log('Promise rejected as expected (file not found):', e.message);
            }
        } else {
            console.log('❌ officeParser.parseOffice does NOT return a Promise. Type:', typeof result);
        }
    } catch (e) {
        console.log('❌ Error calling officeParser:', e.message);
    }
}

checkApi();

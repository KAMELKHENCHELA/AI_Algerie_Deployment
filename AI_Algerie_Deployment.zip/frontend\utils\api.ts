const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002/api';

export const streamChat = async (
    message: string,
    model: string,
    onChunk: (text: string) => void,
    onStatus?: (status: string) => void,
    fileContent?: string
) => {
    try {
        const response = await fetch(`${API_BASE_URL}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
            },
            body: JSON.stringify({ message, model, fileContent }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const reader = response.body?.getReader();
        if (!reader) throw new Error('Response body is empty');

        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });

            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6).trim();
                    if (data === '[DONE]' || !data) continue;

                    try {
                        const parsed = JSON.parse(data);
                        if (parsed.content) {
                            onChunk(parsed.content);
                        } else if (parsed.status) {
                            onStatus?.(parsed.status);
                        } else if (parsed.error) {
                            throw new Error(parsed.error);
                        }
                    } catch (e) {
                        // If not valid JSON but starts with data: , it might be raw text content
                        onChunk(data);
                    }
                }
            }
        }
    } catch (error: any) {
        console.error('Streaming API Error:', error);
        if (error.name === 'AbortError') {
            console.log('Fetch aborted');
        } else if (error.message.includes('fetch')) {
            console.error('Network Error: Failed to reach the server. Is it running on port 3002?');
        }
        throw error;
    }
};

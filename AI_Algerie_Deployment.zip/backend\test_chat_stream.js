import fetch from 'node-fetch';
import jwt from 'jsonwebtoken';

const SECRET_KEY = "your-secure-random-key-min-32-characters-please-change";
const API_URL = 'http://localhost:3002/api/chat'; // Changed to standard chat endpoint

async function testChatStream() {
    const token = jwt.sign({ userId: 1, email: "test@example.com" }, SECRET_KEY, { expiresIn: '1h' });

    console.log("🚀 Starting Chat Stream Test...");
    const startTime = Date.now();

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                message: "code", // Should trigger coding_expert
                model: "gpt"
            })
        });

        if (!response.ok) {
            const errText = await response.text();
            throw new Error(`HTTP Error: ${response.status} ${response.statusText} - ${errText}`);
        }

        console.log("✅ Connection established. Receiving stream...");

        for await (const chunk of response.body) {
            const text = chunk.toString();
            console.log(`[${Date.now() - startTime}ms] Received chunk: ${text.length} bytes`);
            console.log(text.substring(0, 100) + "..."); // Print start of chunk
        }

        console.log(`✅ Stream finished in ${Date.now() - startTime}ms`);

    } catch (error) {
        console.error("❌ Stream Test Failed:", error);
    }
}

testChatStream();

import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

class AIService {
    async askModel(model, message) {
        switch (model) {
            case "gpt":
            case "openai":
                return this.callOpenAI(message);
            case "claude":
                return this.callClaude(message);
            case "deepseek":
                return this.callDeepSeek(message);
            default:
                return this.callOpenAI(message);
        }
    }

    async callOpenAI(message) {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey || apiKey === "sk-your-openai-key-here") {
            throw new Error("OpenAI API Key not configured");
        }

        const response = await axios({
            method: "post",
            url: "https://api.openai.com/v1/chat/completions",
            headers: {
                "Authorization": `Bearer ${apiKey}`,
                "Content-Type": "application/json"
            },
            data: {
                model: "gpt-4-turbo-preview",
                messages: [{ role: "user", content: message }],
                stream: true
            },
            responseType: "stream"
        });

        return { body: response.data };
    }

    async callClaude(message) {
        const apiKey = process.env.ANTHROPIC_API_KEY;
        if (!apiKey || apiKey === "your-anthropic-key-here") {
            throw new Error("Anthropic API Key not configured");
        }

        const response = await axios({
            method: "post",
            url: "https://api.anthropic.com/v1/messages",
            headers: {
                "x-api-key": apiKey,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            data: {
                model: "claude-3-opus-20240229",
                max_tokens: 4096,
                messages: [{ role: "user", content: message }],
                stream: true
            },
            responseType: "stream"
        });

        return { body: response.data };
    }

    async callDeepSeek(message) {
        const apiKey = process.env.DEEPSEEK_API_KEY;
        if (!apiKey || apiKey === "your-deepseek-key-here") {
            throw new Error("DeepSeek API Key not configured");
        }

        const response = await axios({
            method: "post",
            url: "https://api.deepseek.com/v1/chat/completions",
            headers: {
                "Authorization": `Bearer ${apiKey}`,
                "Content-Type": "application/json"
            },
            data: {
                model: "deepseek-chat",
                messages: [{ role: "user", content: message }],
                stream: true
            },
            responseType: "stream"
        });

        return { body: response.data };
    }
}

export default new AIService();

'use client'

import React, { useEffect, useState } from 'react'
import { BarChart3, Users, DollarSign, Activity } from 'lucide-react'

const AdminDashboard = () => {
    const [stats, setStats] = useState<any>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const response = await fetch('http://localhost:3002/api/admin/stats', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                })
                if (response.ok) {
                    const data = await response.json()
                    setStats(data)
                }
            } catch (error) {
                console.error('Failed to fetch admin stats:', error)
            } finally {
                setLoading(false)
            }
        }
        fetchStats()
    }, [])

    if (loading) return <div className="p-8 text-center text-slate-400">جاري تحميل بيانات لوحة التحكم...</div>

    const statCards = [
        { title: 'إجمالي المستخدمين', value: stats?.totalUsers || 0, icon: <Users className="text-blue-400" />, trend: '+12%' },
        { title: 'مستخدمي Pro', value: stats?.proUsers || 0, icon: <Activity className="text-emerald-400" />, trend: '+5%' },
        { title: 'إجمالي الأرباح', value: `${stats?.totalRevenue || 0} دج`, icon: <DollarSign className="text-yellow-400" />, trend: '+20%' },
        { title: 'أداء النظام', value: '99.9%', icon: <BarChart3 className="text-purple-400" />, trend: 'مستقر' },
    ]

    return (
        <div className="p-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-500">
                لوحة تحكم المدير - Titan Enterprise
            </h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {statCards.map((card, i) => (
                    <div key={i} className="titan-glass p-6 rounded-3xl border border-white/5 hover:border-emerald-500/30 transition-all group">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-3 bg-slate-800/50 rounded-2xl group-hover:scale-110 transition-transform">
                                {card.icon}
                            </div>
                            <span className="text-xs font-medium text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full">
                                {card.trend}
                            </span>
                        </div>
                        <h3 className="text-slate-400 text-sm mb-1">{card.title}</h3>
                        <p className="text-2xl font-bold text-white">{card.value}</p>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="titan-glass p-8 rounded-3xl border border-white/5">
                    <h2 className="text-xl font-semibold mb-6">تحليل الإيرادات الشهرية</h2>
                    <div className="h-64 flex items-end gap-2 justify-between px-4 pb-2 border-b border-white/10">
                        {[40, 60, 45, 90, 65, 80, 100].map((h, i) => (
                            <div
                                key={i}
                                style={{ height: `${h}%` }}
                                className="w-full bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-lg hover:from-blue-600 hover:to-blue-400 transition-all cursor-pointer relative group"
                            >
                                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 px-2 py-1 rounded text-[10px] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                    {h * 1000} دج
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="flex justify-between mt-4 text-xs text-slate-500 px-4">
                        <span>أفريل</span><span>ماي</span><span>جوان</span><span>جويلية</span><span>أوت</span><span>سبتمبر</span><span>أكتوبر</span>
                    </div>
                </div>

                <div className="titan-glass p-8 rounded-3xl border border-white/5">
                    <h2 className="text-xl font-semibold mb-6">آخر العمليات</h2>
                    <div className="space-y-4">
                        {[1, 2, 3, 4].map((_, i) => (
                            <div key={i} className="flex justify-between items-center p-4 bg-white/5 rounded-2xl border border-white/5">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold">U</div>
                                    <div>
                                        <p className="text-sm font-medium">مستخدم #{1200 + i}</p>
                                        <p className="text-xs text-slate-500">اشتراك Pro - بطاقة ذهبية</p>
                                    </div>
                                </div>
                                <span className="text-sm font-bold text-emerald-400">+1500 دج</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AdminDashboard

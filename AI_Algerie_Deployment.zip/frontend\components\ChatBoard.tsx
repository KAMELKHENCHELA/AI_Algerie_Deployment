'use client'

import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Zap, Star, Copy, Check } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'

const CodeBlock = ({ language, value }: { language: string, value: string }) => {
    const [copied, setCopied] = React.useState(false)

    const handleCopy = () => {
        navigator.clipboard.writeText(value)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    return (
        <div className="relative group">
            <button
                onClick={handleCopy}
                className="absolute right-2 top-2 p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 opacity-0 group-hover:opacity-100 transition-all z-10"
                title="نسخ الكود"
            >
                {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
            </button>
            <SyntaxHighlighter
                style={oneDark}
                language={language}
                PreTag="div"
                className="rounded-xl !bg-slate-950/50 !my-0"
            >
                {value}
            </SyntaxHighlighter>
        </div>
    )
}

interface Message {
    role: 'ai' | 'user'
    content: string
}

interface ChatBoardProps {
    messages: Message[]
    isThinking: boolean
}

const ChatBoard = ({ messages, isThinking }: ChatBoardProps) => {
    const scrollRef = React.useRef<HTMLDivElement>(null)

    React.useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight
        }
    }, [messages, isThinking])

    return (
        <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pr-2 scroll-smooth">
            <AnimatePresence initial={false}>
                {messages.map((m, i) => (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        key={i}
                        className={`flex gap-4 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}
                    >
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${m.role === 'ai' ? 'bg-gradient-to-br from-emerald-500 to-blue-600' : 'bg-titan-emerald'}`}>
                            {m.role === 'ai' ? <Zap size={20} /> : <Star size={20} />}
                        </div>
                        <div className={`max-w-[80%] p-4 rounded-2xl ${m.role === 'ai' ? 'bg-white/5 rounded-tr-none' : 'bg-titan-emerald text-white rounded-tl-none shadow-lg shadow-emerald-500/20'}`}>
                            <div className="leading-relaxed prose prose-invert max-w-none">
                                <ReactMarkdown
                                    remarkPlugins={[remarkGfm]}
                                    components={{
                                        code({ node, inline, className, children, ...props }: any) {
                                            const match = /language-(\w+)/.exec(className || '')
                                            const value = String(children).replace(/\n$/, '')
                                            return !inline && match ? (
                                                <CodeBlock language={match[1]} value={value} />
                                            ) : (
                                                <code className={className} {...props}>
                                                    {children}
                                                </code>
                                            )
                                        }
                                    }}
                                >
                                    {m.content}
                                </ReactMarkdown>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </AnimatePresence>
            {isThinking && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex gap-4"
                >
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-blue-600/20 flex items-center justify-center border border-white/5">
                        <Zap size={20} className="text-titan-emerald animate-pulse" />
                    </div>
                    <div className="bg-white/5 p-4 rounded-2xl rounded-tr-none flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-titan-emerald rounded-full animate-bounce [animation-delay:-0.3s]" />
                        <div className="w-1.5 h-1.5 bg-titan-emerald rounded-full animate-bounce [animation-delay:-0.15s]" />
                        <div className="w-1.5 h-1.5 bg-titan-emerald rounded-full animate-bounce" />
                    </div>
                </motion.div>
            )}
        </div>
    )
}

export default React.memo(ChatBoard)

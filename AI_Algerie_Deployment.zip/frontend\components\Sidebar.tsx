'use client'

import React from 'react'
import { Zap, BookOpen, LogOut, CreditCard, ShieldAlert } from 'lucide-react'

interface SidebarProps {
    onClearChat?: () => void;
    activeView: 'chat' | 'pricing' | 'admin';
    onViewChange: (view: 'chat' | 'pricing' | 'admin') => void;
    isAdminUser: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ onClearChat, activeView, onViewChange, isAdminUser }) => {
    return (
        <aside className="w-64 titan-glass m-4 rounded-3xl p-6 flex flex-col gap-8">
            <div className="flex items-center gap-3 text-xl font-bold">
                <Zap className="text-titan-emerald" />
                <span>AI Algérie</span>
            </div>

            <nav className="flex-1 flex flex-col gap-2">
                <button
                    onClick={() => onViewChange('chat')}
                    className={`flex items-center gap-4 p-3 rounded-xl transition-all ${activeView === 'chat' ? 'bg-titan-emerald/10 text-titan-emerald font-semibold' : 'text-slate-400 hover:bg-white/5'}`}
                >
                    <BookOpen size={20} />
                    <span>دردشة جديدة</span>
                </button>

                <button
                    onClick={() => onViewChange('pricing')}
                    className={`flex items-center gap-4 p-3 rounded-xl transition-all ${activeView === 'pricing' ? 'bg-emerald-500/10 text-emerald-400 font-semibold' : 'text-slate-400 hover:bg-white/5'}`}
                >
                    <CreditCard size={20} />
                    <span>ترقية الحساب</span>
                </button>

                {isAdminUser && (
                    <button
                        onClick={() => onViewChange('admin')}
                        className={`flex items-center gap-4 p-3 rounded-xl transition-all ${activeView === 'admin' ? 'bg-blue-500/10 text-blue-400 font-semibold' : 'text-slate-400 hover:bg-white/5'}`}
                    >
                        <ShieldAlert size={20} />
                        <span>لوحة التحكم</span>
                    </button>
                )}
            </nav>

            <button
                onClick={() => onClearChat?.()}
                className="flex items-center gap-4 p-3 rounded-xl text-red-400 hover:bg-red-400/10 transition-all mt-auto"
            >
                <LogOut size={20} />
                <span>مسح المحادثة</span>
            </button>
        </aside>
    )
}

export default React.memo(Sidebar)

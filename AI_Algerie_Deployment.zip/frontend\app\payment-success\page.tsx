'use client'

import React, { useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import { useRouter } from 'next/navigation'

const PaymentSuccess = () => {
    const router = useRouter()

    useEffect(() => {
        const timer = setTimeout(() => {
            router.push('/')
        }, 5000)
        return () => clearTimeout(timer)
    }, [router])

    return (
        <div className="min-h-screen bg-[#020617] text-white flex items-center justify-center p-4">
            <div className="titan-glass p-12 rounded-[3rem] border border-emerald-500/30 max-w-md w-full text-center">
                <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
                    <CheckCircle2 size={48} className="text-emerald-400" />
                </div>
                <h1 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-emerald-200">
                    تمت عملية الترقية بنجاح!
                </h1>
                <p className="text-slate-400 mb-8 leading-relaxed">
                    شكراً لك على ثقتك في تيتان. تم تحديث حسابك بنجاح بجميع الميزات المتقدمة.
                </p>
                <div className="text-sm text-slate-500 animate-pulse">
                    سيتم تحويلك إلى الصفحة الرئيسية خلال 5 ثوانٍ...
                </div>
                <button
                    onClick={() => router.push('/')}
                    className="mt-8 w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold transition-all shadow-lg shadow-emerald-500/20"
                >
                    العودة الآن
                </button>
            </div>
        </div>
    )
}

export default PaymentSuccess

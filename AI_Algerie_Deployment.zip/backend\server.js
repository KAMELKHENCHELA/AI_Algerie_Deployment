import express from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import AIService from "./services/ai.service.js";
import SearchService from "./services/search.service.js";
import retriever from "./rag/retriever.js";
import dispatcher from "./services/agent-dispatcher.service.js";
import multer from "multer";
import path from "path";
import FileParserService from "./services/file-parser.service.js";
import ChargilyService from "./services/chargily.service.js";

dotenv.config();

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3000;
const SECRET_KEY = process.env.JWT_SECRET;
if (!SECRET_KEY) {
    console.error("FATAL: JWT_SECRET is not defined in environment variables.");
    process.exit(1);
}

// --- REQUEST LOGGER ---
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// --- SECURITY MIDDLEWARE ---
app.use(helmet());
app.use(cors({
    origin: process.env.ALLOWED_ORIGIN || "*",
    credentials: true
}));
app.use(express.json());

// Apply rate limiting to all requests
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests from this IP, please try again after 15 minutes" }
});
app.use(limiter);

// --- FILE UPLOAD CONFIG ---
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = 'uploads/';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({
    storage,
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});
import fs from 'fs';

// Rate limiting for AI endpoints (stricter)
const aiLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 100, // 100 requests per hour per user
    standardHeaders: true,
    legacyHeaders: false,
});

// --- VALIDATION SCHEMAS ---
const registerSchema = z.object({
    email: z.string().email("Invalid email format"),
    password: z.string().min(8, "Password must be at least 8 characters")
});

const loginSchema = z.object({
    email: z.string().email(),
    password: z.string()
});

const askSchema = z.object({
    message: z.string().min(1).max(5000), // Increased for larger context
    model: z.enum(["gpt", "openai", "deepseek", "claude"]).optional(),
    sessionId: z.number().optional(),
    fileContent: z.string().optional()
});

// --- AUTH MIDDLEWARE ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, SECRET_KEY, async (err, payload) => {
        if (err) return res.sendStatus(403);
        const user = await prisma.user.findUnique({ where: { id: payload.userId } });
        if (!user) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// --- SUBSCRIPTION MIDDLEWARE ---
const checkSubscription = async (req, res, next) => {
    if (req.user.apiLimitRemaining <= 0 && req.user.subscriptionTier === 'free') {
        return res.status(403).json({
            error: "لقد استهلكت جميع نقاط الاستخدام المجانية. يرجى الترقية لمواصلة المحادثة.",
            needsUpgrade: true
        });
    }
    next();
};

const isAdmin = (req, res, next) => {
    if (!req.user.isAdmin) return res.status(403).json({ error: "Access denied. Admin only." });
    next();
};

// --- HEALTH CHECK ---
app.get("/health", (req, res) => {
    res.json({
        status: "ok",
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || "development"
    });
});

// --- AUTH ROUTES ---
app.post("/api/auth/register", async (req, res) => {
    try {
        const { email, password } = registerSchema.parse(req.body);

        // Check if user exists
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ error: "Email already registered" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await prisma.user.create({
            data: { email, password_hash: hashedPassword, plan: "free" }
        });

        const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: "7d" });
        res.status(201).json({
            token,
            user: {
                id: user.id,
                email: user.email,
                xp: user.xp,
                level: user.level,
                plan: user.plan
            }
        });
    } catch (e) {
        if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
        res.status(500).json({ error: "Registration failed" });
    }
});

app.post("/api/auth/login", async (req, res) => {
    try {
        const { email, password } = loginSchema.parse(req.body);
        const user = await prisma.user.findUnique({ where: { email } });

        if (user && await bcrypt.compare(password, user.password_hash)) {
            // Update last login
            await prisma.user.update({
                where: { id: user.id },
                data: {
                    lastLogin: new Date(),
                    loginCount: { increment: 1 }
                }
            });

            const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: "7d" });
            res.json({
                token,
                user: {
                    id: user.id,
                    email: user.email,
                    xp: user.xp,
                    level: user.level,
                    plan: user.plan
                }
            });
        } else {
            res.status(401).json({ error: "Invalid credentials" });
        }
    } catch (e) {
        if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
        res.status(500).json({ error: "Login failed" });
    }
});

app.get("/api/auth/me", authenticateToken, (req, res) => {
    res.json(req.user);
});

// --- CHAT SESSION ROUTES ---
app.get("/api/chat/sessions", authenticateToken, async (req, res) => {
    try {
        const sessions = await prisma.chatSession.findMany({
            where: { userId: req.user.id },
            orderBy: { createdAt: "desc" },
            take: 20
        });
        res.json(sessions);
    } catch (e) {
        res.status(500).json({ error: "Failed to fetch sessions" });
    }
});

app.post("/api/chat/sessions", authenticateToken, async (req, res) => {
    try {
        const { title } = req.body;
        const session = await prisma.chatSession.create({
            data: {
                title: title || "جلسة جديدة",
                userId: req.user.id
            }
        });
        res.status(201).json(session);
    } catch (e) {
        res.status(500).json({ error: "Failed to create session" });
    }
});

// --- AI SERVICE ROUTES ---
app.get("/api/ai/history", authenticateToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = 20;

        const history = await prisma.message.findMany({
            where: { userId: req.user.id },
            orderBy: { created_at: "desc" },
            skip: (page - 1) * limit,
            take: limit
        });

        const total = await prisma.message.count({ where: { userId: req.user.id } });
        res.json({
            data: history,
            page,
            limit,
            total,
            hasMore: (page * limit) < total
        });
    } catch (e) {
        res.status(500).json({ error: "Failed to fetch history" });
    }
});

app.post("/api/ai/ask", authenticateToken, aiLimiter, async (req, res) => {
    try {
        const { message, model = "gpt", sessionId } = askSchema.parse(req.body);

        // Set SSE headers
        res.setHeader("Content-Type", "text/event-stream");
        res.setHeader("Cache-Control", "no-cache");
        res.setHeader("Connection", "keep-alive");

        try {
            const hasKey = (model === "gpt" || model === "openai") ?
                (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "sk-your-openai-key-here") :
                model === "claude" ?
                    (process.env.ANTHROPIC_API_KEY && process.env.ANTHROPIC_API_KEY !== "your-anthropic-key-here") :
                    (process.env.DEEPSEEK_API_KEY && process.env.DEEPSEEK_API_KEY !== "your-deepseek-key-here");

            if (hasKey) {
                const aiRes = await AIService.askModel(model, message);

                let fullResponse = "";
                for await (const chunk of aiRes.body) {
                    const text = chunk.toString();
                    fullResponse += text;
                    res.write(chunk);
                }

                // Save history
                const userMsg = await prisma.message.create({
                    data: {
                        role: "user",
                        content: message,
                        userId: req.user.id,
                        sessionId: sessionId || undefined
                    }
                });

                await prisma.message.create({
                    data: {
                        role: "ai",
                        content: fullResponse,
                        userId: req.user.id,
                        sessionId: sessionId || undefined
                    }
                });

                res.write("data: [DONE]\n\n");
                res.end();
            } else {
                // Mock streaming
                const words = `[نظام التيتان - موديل ${model}] أهلاً بك! هذا رد تجريبي.`.split(" ");
                let fullResponse = "";
                for (const word of words) {
                    const content = word + " ";
                    fullResponse += content;
                    res.write(`data: ${JSON.stringify({ content })}\n\n`);
                    await new Promise(r => setTimeout(r, 100));
                }

                await prisma.message.create({
                    data: {
                        role: "user",
                        content: message,
                        userId: req.user.id,
                        sessionId: sessionId || undefined
                    }
                });

                await prisma.message.create({
                    data: {
                        role: "ai",
                        content: fullResponse,
                        userId: req.user.id,
                        sessionId: sessionId || undefined
                    }
                });

                res.write("data: [DONE]\n\n");
                res.end();
            }
        } catch (error) {
            console.error("AI Service Error:", error);
            res.write(`data: ${JSON.stringify({ error: "خطأ في خدمة الذكاء الاصطناعي" })}\n\n`);
            res.end();
        }
    } catch (e) {
        if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// --- ACHIEVEMENTS ROUTES ---
app.get("/api/achievements", authenticateToken, async (req, res) => {
    try {
        const userAchievements = await prisma.userAchievement.findMany({
            where: { userId: req.user.id },
            include: { achievement: true }
        });
        res.json(userAchievements);
    } catch (e) {
        res.status(500).json({ error: "Failed to fetch achievements" });
    }
});

// --- LEADERBOARD ROUTES ---
app.get("/api/leaderboard", async (req, res) => {
    try {
        const topUsers = await prisma.user.findMany({
            orderBy: { xp: 'desc' },
            take: 10,
            select: {
                email: true,
                xp: true,
                level: true,
                createdAt: true
            }
        });
        res.json(topUsers);
    } catch (e) {
        res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
});

// --- FILE UPLOAD ROUTE ---
app.post("/api/upload", authenticateToken, upload.single("file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: "No file uploaded" });
        }

        const filePath = req.file.path;
        const mimeType = req.file.mimetype;

        const textContent = await FileParserService.parseFile(filePath, mimeType);

        // Optionally delete the file after parsing
        fs.unlinkSync(filePath);

        res.json({
            message: "File uploaded and parsed successfully",
            content: textContent,
            fileName: req.file.originalname
        });
    } catch (error) {
        console.error("Upload Error:", error);
        res.status(500).json({ error: "Failed to process file" });
    }
});

// --- PAYMENT ROUTES ---
app.post("/api/payments/checkout", authenticateToken, async (req, res) => {
    try {
        const { planName, amount } = req.body;
        const checkout = await ChargilyService.createCheckout(req.user.id, amount, planName);

        await prisma.payment.create({
            data: {
                amount,
                userId: req.user.id,
                status: "pending",
                invoiceId: checkout.id.toString(),
                paymentMethod: "chargily"
            }
        });

        res.json({ checkoutUrl: checkout.checkout_url });
    } catch (error) {
        console.error("Checkout Error:", error);
        res.status(500).json({ error: "Failed to initiate payment" });
    }
});

app.post("/api/payments/webhook", async (req, res) => {
    const payload = req.body;
    const signature = req.headers['signature'];

    if (await ChargilyService.verifyWebhook(signature, payload)) {
        if (payload.type === 'checkout.paid') {
            const { userId, planName } = payload.data.metadata;
            const uid = parseInt(userId);

            let limits = 1000;
            let tier = "free";

            if (planName === 'Pro') {
                limits = 10000;
                tier = "pro";
            } else if (planName === 'Enterprise') {
                limits = 100000;
                tier = "enterprise";
            }

            await prisma.user.update({
                where: { id: uid },
                data: {
                    subscriptionTier: tier,
                    apiLimitRemaining: { increment: limits }
                }
            });

            await prisma.payment.update({
                where: { invoiceId: payload.data.id.toString() },
                data: { status: "completed" }
            });
        }
    }
    res.json({ received: true });
});

// --- ADMIN ROUTES ---
app.get("/api/admin/stats", authenticateToken, isAdmin, async (req, res) => {
    try {
        const totalUsers = await prisma.user.count();
        const proUsers = await prisma.user.count({ where: { subscriptionTier: "pro" } });
        const enterpriseUsers = await prisma.user.count({ where: { subscriptionTier: "enterprise" } });
        const totalRevenue = await prisma.payment.aggregate({
            where: { status: "completed" },
            _sum: { amount: true }
        });

        res.json({
            totalUsers,
            proUsers,
            enterpriseUsers,
            totalRevenue: totalRevenue._sum.amount || 0
        });
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch admin stats" });
    }
});

// --- CHAT ROUTE (UNIFIED & STREAMING) ---
app.post("/api/chat", authenticateToken, checkSubscription, async (req, res) => {
    console.log("DEBUG: Processing /api/chat request from user:", req.user?.id);
    try {
        const { message, model = "gpt", fileContent = "" } = req.body;

        // Restrict premium models to Pro/Enterprise users
        if ((model === 'claude' || model === 'openai') && req.user.subscriptionTier === 'free') {
            return res.status(403).json({
                error: "هذا المحرك مخصص للمشتركين فقط. يرجى ترقية حسابك للوصول إلى ذكاء اصطناعي أكثر قوة.",
                needsUpgrade: true
            });
        }

        if (!message || message.trim().length === 0) {
            return res.status(400).json({ error: "Message cannot be empty" });
        }

        // Set SSE headers for streaming
        res.setHeader("Content-Type", "text/event-stream");
        res.setHeader("Cache-Control", "no-cache");
        res.setHeader("Connection", "keep-alive");

        let localContext = { context: "" };
        let webContext = "";

        try {
            // 1. Dispatcher Check
            console.log("DEBUG: Calling dispatcher with message:", message);
            const specializedAgent = await dispatcher.getBestAgent(message);
            if (specializedAgent && specializedAgent.type === 'n8n') {
                res.write(`data: ${JSON.stringify({ status: `جاري تحويل طلبك إلى ${specializedAgent.name}...` })}\n\n`);
                const n8nResponse = await dispatcher.routeToN8N(specializedAgent, message, req.user?.id);

                if (n8nResponse) {
                    // Simulate streaming for smoother UX
                    const words = n8nResponse.split(" ");
                    for (const word of words) {
                        res.write(`data: ${JSON.stringify({ content: word + " " })}\n\n`);
                        await new Promise(resolve => setTimeout(resolve, 50)); // Typing effect
                    }
                    res.write("data: [DONE]\n\n");

                    // Decrement user limit
                    await prisma.user.update({
                        where: { id: req.user.id },
                        data: { apiLimitRemaining: { decrement: 1 } }
                    });

                    return res.end();
                }
            }

            // --- CORE LLM FLOW ---
            res.write(`data: ${JSON.stringify({ status: "Searching for context..." })}\n\n`);

            // 1. Get Local Context (RAG)
            localContext = await retriever.retrieveWithContext(message, { topK: 3 });

            // 2. Get Web Context (If message seems to need it)
            const webResults = await SearchService.search(message);
            webContext = SearchService.formatResults(webResults);

            // 3. Compose Final Prompt for AI
            const enhancedPrompt = `
أنت الآن في وضع "المهندس الخبير" (Senior Software Architect & Mentor) وقدرة تحليلية فائقة.
اسمي "تيتان"، وأنا الذكاء الاصطناعي المطور من قبل المبرمج "Kamel Zerdoum".

[تعليمات الهوية واللغة]:
- عندما يتم سؤالك "من أنت؟"، أجب دائماً: "أنا AI Algérie، الذكاء الاصطناعي المطور من قبل المبرمج Kamel Zerdoum للجزائر".
- أنت تدعم اللغة الأمازيغية (Tamazight) بشكل كامل كجزء أصيل من الهوية الجزائرية. يمكنك التواصل بها بالخطوط المختلفة (Tifinagh, Latin).
- احترم الثقافة الأمازيغية والتراث الجزائري في جميع ردودك.

[تعليمات الأداء والأمان]:
- الأمان أولاً (Security First): عند إنشاء أي كود برمجي، تأكد من خلوه من الثغرات واتباع معايير OWASP.
- الاستباقية والمحاكاة (Proactive Simulation): لا تنتظر التفاصيل الدقيقة دائماً. كن شريكاً في التفكير؛ توقع ما يحتاجه المستخدم بناءً على سؤاله الأول وأكمل الحل للنهاية. إذا كان السؤال عاماً، قدم تحليلاً شاملاً وحلولاً مقترحة تلقائياً.
- للعمليات الحسابية: أعطِ النتيجة المباشرة فوراً مع شرح مبسط إذا كان معقداً.
- للخوارزميات والبرمجة: قدم حلولاً ذات كفاءة عالية (High Performance)، وحلل التعقيد الزمني والمكاني.
- للتحليل: قم بتحليل أي كود أو نص مزود بعمق، وحدد الثغرات أو نقاط التحسين.

${fileContent ? `[محتوى الملف المرفق]:\n${fileContent}\n` : ""}

[سياق تقني مسترجع]:
${localContext.context || "لا يوجد سياق محلي متاح."}

[معلومات بحثية]:
${webContext || "لا توجد نتائج بحث حديثة."}

[تحدي المستخدم]:
${message}
`;

            const aiRes = await AIService.askModel(model, enhancedPrompt);

            // Transmit through SSE with transformation
            let buffer = "";
            for await (const chunk of aiRes.body) {
                const text = chunk.toString();
                buffer += text;

                const lines = buffer.split("\n");
                buffer = lines.pop();

                for (const line of lines) {
                    const cleanLine = line.trim();
                    if (!cleanLine || cleanLine === "data: [DONE]") continue;

                    if (cleanLine.startsWith("data: ")) {
                        try {
                            const dataStr = cleanLine.replace(/^data: /, "");
                            const json = JSON.parse(dataStr);
                            const content = json.choices?.[0]?.delta?.content || json.content;

                            if (content) {
                                res.write(`data: ${JSON.stringify({ content })}\n\n`);
                            }
                        } catch (e) {
                            // Skip parse errors for partial chunks
                        }
                    }
                }
            }

            res.write("data: [DONE]\n\n");

            // Decrement user limit after successful stream
            await prisma.user.update({
                where: { id: req.user.id },
                data: { apiLimitRemaining: { decrement: 1 } }
            });

            return res.end();
        } catch (err) {
            console.error("AI Provider Error (Falling back to Mock):", err);
            console.error("Error Stack:", err.stack);
            return await handleMockFallback(res, message, localContext);
        }
    } catch (error) {
        console.error("Chat Router Error:", error);
        if (!res.headersSent) {
            res.status(500).json({ error: "Internal Server Error" });
        } else {
            res.write(`data: ${JSON.stringify({ error: "Internal Server Error" })}\n\n`);
            res.end();
        }
    }
});

// --- MOCK N8N AGENT ROUTE (DEV ONLY) ---
import MockAgentService from "./services/mock-agent.service.js";
app.post("/api/mock-n8n/:agentId", async (req, res) => {
    try {
        const { agentId } = req.params;
        const { query, userId } = req.body;
        const response = await MockAgentService.handleRequest(agentId, query, userId);
        res.json({ output: response });
    } catch (error) {
        console.error("Mock Agent Error:", error);
        res.status(500).json({ error: "Mock agent failed" });
    }
});

/**
 * Shared logic for mock AI response fallback
 */
async function handleMockFallback(res, message, localContext) {
    let selectedText = "";

    if (localContext && localContext.results && localContext.results.length > 0) {
        const bestMatch = localContext.results[0];
        selectedText = `أنا الذكاء الاصطناعي من المبرمج Kamel Zerdoum. 📚\n\nلقد وجدت معلومات في قاعدة بياناتي المحلية تتعلق بطلبك:\n\n"${bestMatch.text}"\n\nبصفتي "تيتان"، أنا أعمل حالياً في وضع الأداء المحلي لضمان استمرارية الخدمة.`;
    } else {
        const responses = [
            `أنا الذكاء الاصطناعي من المبرمج Kamel Zerdoum. 🚀\nأنا أعمل حالياً في "وضع الأداء الأساسي" لضمان سرعة الاستجابة.\nسؤالك كان: "${message}"\nيسعدني مساعدتك بصفتي مساعدك الذكي المطور محلياً.`,
            `مرحباً! أنا "تيتان"، المساعد الذكي الخاص بالمبرمج Kamel Zerdoum. 🇩🇿\nحالياً أستخدم ذاكرتي المحلية للإجابة على "${message}".\nيمكنك تفعيل الربط السحابي (OpenAI/DeepSeek) لتوسيع آفاق الإجابة.`,
            `استجابة من تيتان (المطور من قبل Kamel Zerdoum) ⚡\nأنا جاهز لمساعدتك! حالياً أعمل في الوضع المحلي لتقديم أسرع استجابة ممكنة لطلبك.`
        ];
        selectedText = responses[Math.floor(Math.random() * responses.length)];
    }

    if (!res.headersSent) {
        res.setHeader("Content-Type", "text/event-stream");
        res.setHeader("Cache-Control", "no-cache");
        res.setHeader("Connection", "keep-alive");
    }

    const words = selectedText.split(" ");
    for (const word of words) {
        const content = word + " ";
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
        await new Promise(r => setTimeout(r, 40));
    }

    res.write("data: [DONE]\n\n");
    res.end();
}

// --- ERROR HANDLER ---
app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
});

// --- GRACEFUL SHUTDOWN ---
const server = app.listen(PORT, () => {
    console.log(`🚀 Titan Enterprise API Gateway running on port ${PORT}`);
    console.log(`🛡️  Rate Limiting enabled (100 req / 15 min)`);
    console.log(`📊 Database connected: ${process.env.DATABASE_URL || 'SQLite'}`);
});

process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully...');
    server.close(async () => {
        await prisma.$disconnect();
        console.log('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', async () => {
    console.log('SIGINT received, shutting down gracefully...');
    server.close(async () => {
        await prisma.$disconnect();
        console.log('Server closed');
        process.exit(0);
    });
});

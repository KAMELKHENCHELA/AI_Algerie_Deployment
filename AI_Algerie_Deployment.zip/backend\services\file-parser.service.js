import fs from "fs/promises";
import officeparser from "officeparser";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const pdf = require("pdf-parse");

class FileParserService {
    async parseFile(filePath, mimeType) {
        try {
            if (mimeType === "application/pdf") {
                return await this.parsePDF(filePath);
            } else if (
                mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                mimeType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ) {
                return await this.parseOffice(filePath);
            } else if (mimeType.startsWith("text/")) {
                return await fs.readFile(filePath, "utf-8");
            } else {
                throw new Error("Unsupported file type: " + mimeType);
            }
        } catch (error) {
            console.error("File Parsing Error:", error);
            throw error;
        }
    }

    async parsePDF(filePath) {
        const dataBuffer = await fs.readFile(filePath);
        const data = await pdf(dataBuffer);
        return data.text;
    }

    async parseOffice(filePath) {
        return new Promise((resolve, reject) => {
            officeparser.parseOffice(filePath, (data, err) => {
                if (err) return reject(err);
                resolve(data);
            });
        });
    }
}

export default new FileParserService();

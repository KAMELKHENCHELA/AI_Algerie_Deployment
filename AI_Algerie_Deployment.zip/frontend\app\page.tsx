'use client'

import { useState, useEffect, useCallback } from 'react'
import Sidebar from '@/components/Sidebar'
import StatsHeader from '@/components/StatsHeader'
import ChatBoard from '@/components/ChatBoard'
import ChatInput from '@/components/ChatInput'
import ModelSelector from '@/components/ModelSelector'
import Pricing from '@/components/Pricing'
import AdminDashboard from '@/components/AdminDashboard'
import { streamChat } from '@/utils/api'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002/api';

export default function Home() {
  const [messages, setMessages] = useState<{ role: 'ai' | 'user', content: string }[]>([])
  const [input, setInput] = useState('')
  const [isThinking, setIsThinking] = useState(false)
  const [selectedModel, setSelectedModel] = useState<'gpt' | 'deepseek' | 'claude'>('gpt')
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [sessionId, setSessionId] = useState<string>('default')
  const [activeView, setActiveView] = useState<'chat' | 'pricing' | 'admin'>('chat')
  const [userProfile, setUserProfile] = useState<any>(null)

  const initialMessage = {
    role: 'ai' as const,
    content: 'أنا الآن جاهز لمساعدتك'
  }

  const fetchUser = async () => {
    try {
      const res = await fetch(`${API_URL}/auth/me`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      if (res.ok) {
        const data = await res.json()
        setUserProfile(data)
      }
    } catch (e) {
      console.error('Failed to fetch user:', e)
    }
  }

  useEffect(() => {
    fetchUser()
  }, [activeView])

  // Load messages from localStorage on mount
  useEffect(() => {
    const savedMessages = localStorage.getItem(`chat_${sessionId}`)
    if (savedMessages) {
      try {
        setMessages(JSON.parse(savedMessages))
      } catch (error) {
        console.error('Failed to load saved messages:', error)
        setMessages([initialMessage])
      }
    } else {
      setMessages([initialMessage])
    }
  }, [sessionId])

  // Save messages to localStorage when they change
  useEffect(() => {
    localStorage.setItem(`chat_${sessionId}`, JSON.stringify(messages))
  }, [messages, sessionId])

  const handleSend = useCallback(async () => {
    if ((!input.trim() && !selectedFile) || isThinking) return
    const userMsg = input
    const file = selectedFile

    setMessages(prev => [...prev, { role: 'user', content: userMsg + (file ? `\n\n*(المرفق: ${file.name})*` : '') }])
    setInput('')
    setSelectedFile(null)
    setIsThinking(true)

    // Add temporary AI message for streaming
    setMessages(prev => [...prev, { role: 'ai', content: '' }])

    try {
      let fileContent = ''
      if (file) {
        // Upload file first
        const formData = new FormData()
        formData.append('file', file)

        const uploadRes = await fetch(`${API_URL}/upload`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}` // Ensure token is passed
          },
          body: formData
        })

        if (uploadRes.ok) {
          const uploadData = await uploadRes.json()
          fileContent = uploadData.content
        } else {
          console.error('File upload failed')
        }
      }

      let fullContent = ''
      await streamChat(userMsg || 'قم بتحليل الملف المرفق', selectedModel, (chunk: string) => {
        setIsThinking(false)
        fullContent += chunk
        setMessages(prev => {
          const newMessages = [...prev]
          const lastIdx = newMessages.length - 1
          if (newMessages[lastIdx].role === 'ai') {
            newMessages[lastIdx] = { ...newMessages[lastIdx], content: fullContent }
          }
          return newMessages
        })
      }, (status) => {
        console.log('AI Status:', status)
      }, fileContent)
    } catch (error: any) {
      console.error('Streaming Error:', error)
      setIsThinking(false)

      const errorMsg = error.message?.includes('upgrade') || error.status === 403
        ? 'لقد استهلكت جميع النقاط أو تحاول الوصول لميزة مقفولة. جاري تحويلك لخيارات الاشتراك...'
        : ' عذراً، حدث خطأ في الاتصال بـ AI Algérie. تأكد من تشغيل الخادم بشكل صحيح. 🛑'

      if (error.status === 403) {
        setTimeout(() => setActiveView('pricing'), 2000)
      }

      setMessages(prev => {
        const newMessages = [...prev]
        const lastIdx = newMessages.length - 1
        newMessages[lastIdx] = {
          role: 'ai',
          content: errorMsg
        }
        return newMessages
      })
    } finally {
      setIsThinking(false)
      fetchUser()
    }
  }, [input, isThinking, selectedModel, selectedFile, sessionId, messages])

  const handleClearChat = () => {
    if (confirm('هل تريد مسح المحادثة؟')) {
      setMessages([initialMessage])
      localStorage.removeItem(`chat_${sessionId}`)
    }
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#020617] text-white">
      <Sidebar
        onClearChat={handleClearChat}
        activeView={activeView}
        onViewChange={setActiveView}
        isAdminUser={userProfile?.isAdmin || false}
      />

      <main className="flex-1 flex flex-col p-4 overflow-hidden">
        <StatsHeader user={userProfile} />

        <section className="flex-1 titan-glass rounded-3xl p-6 overflow-hidden flex flex-col">
          {activeView === 'chat' && (
            <>
              <ModelSelector selectedModel={selectedModel} onModelChange={setSelectedModel} />
              <ChatBoard messages={messages} isThinking={isThinking} />
              <ChatInput
                input={input}
                setInput={setInput}
                onSend={handleSend}
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
              />
            </>
          )}
          {activeView === 'pricing' && <Pricing />}
          {activeView === 'admin' && <AdminDashboard />}
        </section>
      </main>
    </div>
  )
}

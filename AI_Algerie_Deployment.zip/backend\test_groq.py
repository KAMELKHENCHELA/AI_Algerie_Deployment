import requests
import os
import json

url = "https://api.groq.com/openai/v1/chat/completions"
key = "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"
headers = {
    "Authorization": f"Bearer {key}",
    "Content-Type": "application/json"
}
data = {
    "model": "llama3-8b-8192",
    "messages": [{"role": "user", "content": "hi"}],
    "max_tokens": 10
}

try:
    response = requests.post(url, headers=headers, json=data)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.text}")
except Exception as e:
    print(f"Error: {e}")

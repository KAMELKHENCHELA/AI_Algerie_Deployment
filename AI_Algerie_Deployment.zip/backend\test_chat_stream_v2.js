import fetch from 'node-fetch';

const BASE_URL = 'http://192.168.100.3:3002/api';

async function testChatStreamV2() {
    const email = `test_chat_${Date.now()}@example.com`;
    const password = "password123";

    console.log(`🚀 Starting Full Chat Test for ${email}...`);

    try {
        // 1. Register to get token
        const regRes = await fetch(`${BASE_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        if (!regRes.ok) throw new Error(`Register failed: ${regRes.status}`);
        const { token } = await regRes.json();
        console.log("✅ Authenticated.");

        // 2. Start Stream
        console.log("2. Sending chat message...");
        const startTime = Date.now();
        const response = await fetch(`${BASE_URL}/ai/ask`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                message: "programming", // Trigger coding_expert
                model: "gpt"
            })
        });

        if (!response.ok) {
            const errText = await response.text();
            throw new Error(`Chat request failed: ${response.status} ${errText}`);
        }

        console.log("✅ Connection established. Receiving stream...");

        let fullContent = "";
        for await (const chunk of response.body) {
            const text = chunk.toString();
            console.log(`[${Date.now() - startTime}ms] Chunk received (${text.length} chars)`);
            fullContent += text;
        }

        console.log(`✅ Stream finished in ${Date.now() - startTime}ms`);
        console.log("--- Response Content ---");
        console.log(fullContent.substring(0, 200) + "...");

    } catch (error) {
        console.error("❌ Test Failed:", error);
    }
}

testChatStreamV2();

class MockAgentService {
    async handleRequest(agentId, query, userId) {
        console.log(`Mock Agent [${agentId}] processing query for user [${userId}]: ${query}`);

        const mockResponses = {
            'math-agent': "بناءً على حساباتي الدقيقة، النتيجة هي 42. (هذا رد تجريبي من وكيل الرياضيات).",
            'legal-agent': "وفقاً للمادة 5 من القانون التجاري الجزائري، يجب توثيق هذا العقد. (هذا رد تجريبي من الوكيل القانوني).",
            'dev-agent': "الخطأ الذي تواجهه ناتج عن محاولة الوصول إلى خاصية في كائن 'undefined'. حاول استخدام 'Optional Chaining'. (هذا رد تجريبي من وكيل البرمجة)."
        };

        return mockResponses[agentId] || "عذراً، لم أتمكن من معالجة هذا الطلب حالياً بصفتي وكيلاً تجريبياً.";
    }
}

export default new MockAgentService();

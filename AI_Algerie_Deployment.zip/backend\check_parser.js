import FileParserService from './services/file-parser.service.js';
import fs from 'fs/promises';
import path from 'path';

async function testParser() {
    const testFile = 'test_parser_file.txt';
    const testContent = 'Hello, this is a test for the file parser service.';

    try {
        // Create a dummy text file
        await fs.writeFile(testFile, testContent);
        console.log(`Created test file: ${testFile}`);

        // Test parsing
        console.log('Testing FileParserService...');
        const result = await FileParserService.parseFile(testFile, 'text/plain');

        if (result === testContent) {
            console.log('✅ Parser test passed! Content matches.');
        } else {
            console.error('❌ Parser test failed!');
            console.error('Expected:', testContent);
            console.error('Received:', result);
        }

    } catch (error) {
        console.error('❌ Error during test:', error);
    } finally {
        // Cleanup
        try {
            await fs.unlink(testFile);
            console.log(`Deleted test file: ${testFile}`);
        } catch (e) {
            console.error('Error deleting test file:', e);
        }
    }
}

testParser();

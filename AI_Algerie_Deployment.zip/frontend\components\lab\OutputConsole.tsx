'use client'

import React from 'react'
import { Terminal, AlertTriangle, CheckCircle } from 'lucide-react'

interface Log {
    type: 'log' | 'error' | 'warn'
    content: string
    timestamp: number
}

interface OutputConsoleProps {
    logs: Log[]
    onClear: () => void
}

const OutputConsole = ({ logs, onClear }: OutputConsoleProps) => {
    return (
        <div className="h-full flex flex-col bg-[#0d1117] rounded-2xl border border-white/10 overflow-hidden">
            <div className="flex justify-between items-center p-3 bg-white/5 border-b border-white/5">
                <div className="flex items-center gap-2 text-slate-400 text-sm font-mono">
                    <Terminal size={16} />
                    <span>Console Output</span>
                </div>
                <button
                    onClick={onClear}
                    className="text-xs text-slate-500 hover:text-white transition-colors"
                >
                    Clear
                </button>
            </div>

            <div className="flex-1 p-4 overflow-y-auto font-mono text-sm space-y-2">
                {logs.length === 0 ? (
                    <div className="text-slate-600 italic">Ready to execute...</div>
                ) : (
                    logs.map((log, i) => (
                        <div key={i} className={`flex gap-2 ${log.type === 'error' ? 'text-red-400' : 'text-slate-300'}`}>
                            <span className="opacity-50 text-[10px] mt-1">
                                {new Date(log.timestamp).toLocaleTimeString([], { hour12: false })}
                            </span>
                            <span className="break-all">{log.content}</span>
                        </div>
                    ))
                )}
            </div>
        </div>
    )
}

export default React.memo(OutputConsole)

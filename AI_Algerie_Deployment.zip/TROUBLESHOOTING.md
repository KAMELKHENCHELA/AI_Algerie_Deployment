# 🆘 دليل استكشاف الأخطاء - Titan Enterprise

## الأسئلة الشائعة والحلول

---

## ❌ Backend Issues

### خطأ: "PORT already in use"

**الأعراض:**
```
Error: listen EADDRINUSE: address already in use :::3000
```

**الحلول:**

**على Linux/Mac:**
```bash
# ابحث عن العملية التي تستخدم المنفذ
lsof -i :3000

# احصل على PID وأوقفه
kill -9 <PID>

# أو استخدم المنفذ آخر
PORT=3001 npm run dev
```

**على Windows:**
```bash
# ابحث عن العملية
netstat -ano | findstr :3000

# احصل على PID وأوقفه
taskkill /PID <PID> /F

# أو استخدم المنفذ آخر
set PORT=3001 && npm run dev
```

---

### خطأ: "Database connection failed"

**الأعراض:**
```
PrismaClientInitializationError: Can't reach database server
```

**الأسباب الممكنة:**

1. **قاعدة البيانات غير موجودة**
```bash
# التحقق وإعادة الإنشاء
npm run db:generate
npm run db:migrate
```

2. **قاعدة البيانات تالفة**
```bash
# حذف وإعادة إنشاء
rm backend/prisma/dev.db
npm run db:migrate
```

3. **مشكلة في DATABASE_URL**
```bash
# تحقق من .env
cat backend/.env | grep DATABASE_URL

# يجب أن يكون واحد من:
# التطوير: file:./dev.db
# الإنتاج: postgresql://user:pass@host:5432/db
```

---

### خطأ: "Cannot find module '@prisma/client'"

**الحل:**
```bash
cd backend
npm install
npm run db:generate
```

---

### خطأ: "JWT verification failed"

**الأعراض:**
```
JsonWebTokenError: invalid token
```

**الحل:**
```bash
# تأكد من JWT_SECRET في .env
cat backend/.env | grep JWT_SECRET

# تأكد من أنه قوي (32+ حرف)
# أغيّره إذا لزم الأمر:
JWT_SECRET="your-new-strong-secret-here-at-least-32-chars"
```

---

### خطأ: "OpenAI API key invalid"

**الأعراض:**
```
OpenAI API error: 401 - Unauthorized
```

**الحلول:**

1. **تحقق من المفتاح**
```bash
grep OPENAI_API_KEY backend/.env
```

2. **تأكد من أنه يبدأ بـ `sk-`**
```bash
# صحيح:
OPENAI_API_KEY=sk-proj-abc123...

# خطأ:
OPENAI_API_KEY=your_api_key_here
```

3. **جرب المفتاح**
```bash
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"
```

---

## ❌ Frontend Issues

### خطأ: "Cannot GET /"

**الأعراض:**
```
Unhandled Runtime Error
Error: Cannot GET /
```

**الحلول:**

1. **تأكد من أن Frontend قيد التشغيل**
```bash
# في Terminal جديد
cd frontend
npm run dev
```

2. **تحقق من المنفذ**
```bash
# يجب أن يكون على 3001
lsof -i :3001
```

3. **فرّغ Cache**
```bash
rm -rf frontend/.next
npm run dev
```

---

### خطأ: "API connection refused"

**الأعراض:**
```
Failed to fetch
net::ERR_CONNECTION_REFUSED
```

**الحلول:**

1. **تأكد من Backend يعمل**
```bash
curl http://localhost:3000/health
```

2. **تحقق من NEXT_PUBLIC_API_URL**
```bash
cat frontend/.env.local | grep NEXT_PUBLIC_API_URL
# يجب أن يكون: http://localhost:3000/api
```

3. **تحقق من CORS**
```bash
cat backend/.env | grep FRONTEND_URL
# يجب أن يكون: http://localhost:3001
```

---

### خطأ: "Module not found: @/components/..."

**الحل:**
```bash
# تأكد من أن الملف موجود
ls frontend/components/ChatBoard.tsx

# أعد تثبيت dependencies
rm -rf frontend/node_modules
npm install
```

---

### خطأ: "localStorage is not defined"

**السبب:** محاولة الوصول للـ localStorage قبل تحميل الصفحة

**الحل:** استخدم `useEffect` مع `typeof window`
```typescript
useEffect(() => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('key');
    // ...
  }
}, []);
```

---

## ❌ Docker Issues

### خطأ: "Cannot connect to Docker daemon"

**الحل:**
```bash
# تأكد من Docker يعمل
docker ps

# إذا لم يعمل، ابدأه:
# على Mac: open -a Docker
# على Linux: sudo systemctl start docker
# على Windows: افتح Docker Desktop
```

---

### خطأ: "Port already allocated"

**الأعراض:**
```
Error response from daemon: driver failed programming external connectivity
Bind for 0.0.0.0:3000 failed
```

**الحل:**
```bash
# أوقف الحاويات
docker compose down

# أو إذا كانت معلقة
docker compose down -v

# أو غيّر المنافذ في docker-compose.yml
```

---

### خطأ: "Out of memory"

**الحل:**
```bash
# قم بتنظيف الحاويات والـ images غير المستخدمة
docker system prune -a

# أو زيادة الذاكرة المتاحة في Docker Desktop
```

---

## ❌ npm/package Issues

### خطأ: "npm ERR! code ERESOLVE"

**الحل:**
```bash
# استخدم legacy peer deps flag
npm install --legacy-peer-deps

# أو حدّث npm
npm install -g npm@latest
```

---

### خطأ: "ENOENT: no such file or directory"

**الحل:**
```bash
# تأكد من أنك في المجلد الصحيح
pwd
ls package.json

# إذا لم تكن، انتقل:
cd backend  # أو cd frontend
npm install
```

---

## ⚠️ Performance Issues

### المشكلة: الـ app بطيء جداً

**الحلول:**

1. **تحقق من استخدام الذاكرة**
```bash
# على Backend
node --inspect server.js

# على Frontend
npm run dev -- --inspect
```

2. **طبّق Caching**
```bash
# استخدم Redis
docker run -d -p 6379:6379 redis:latest
```

3. **أضف Pagination**
- استخدم `skip` و `take` في Prisma
- حدّد عدد الـ messages المعادة

---

## ⚠️ صعوبات في التطوير

### لا يمكن الوصول إلى Prisma Studio

**الحل:**
```bash
cd backend
npm run db:studio
# سيفتح على: http://localhost:5555
```

---

### Hot Reload لا يعمل

**الحل:**
```bash
# تأكد من استخدام nodemon
npm run dev  # وليس npm start

# أو في Docker
docker compose logs -f backend
```

---

### Git conflicts في package-lock.json

**الحل:**
```bash
# أعد تثبيت dependencies
rm -rf node_modules package-lock.json
npm install
git add package.json package-lock.json
```

---

## 🔍 Debug Tips

### استخدم VS Code Debugger

**Backend:**
```javascript
// ضع breakpoint في الكود
// F5 لبدء Debug
```

**Frontend:**
```javascript
// استخدم DevTools (F12)
// أو VS Code extension: Debugger for Chrome
```

### استخدم Logs

```javascript
// Backend
console.log('Message:', variable);
console.error('Error:', error);

// Frontend
console.table(data);
console.time('operation');
```

### استخدم Prisma Studio

```bash
npm run db:studio
# يفتح واجهة رسومية لـ قاعدة البيانات
```

---

## 📞 طلب المساعدة

إذا لم تحل المشكلة:

1. **اجمع المعلومات:**
```bash
# نسخ معلومات النظام
node --version
npm --version
docker --version

# نسخ الخطأ كاملاً
```

2. **ابحث في Issues:**
- https://github.com/your-repo/titan/issues

3. **أنشئ Issue جديد:**
- صف المشكلة بوضوح
- أرفق السجلات (logs)
- أرفق نسخة من `.env` (بدون مفاتيح API)

4. **اطلب المساعدة:**
- Discord: [رابط السيرفر]
- Email: support@titan.dz

---

## ✅ التحقق من الحل

بعد حل المشكلة:

```bash
# اختبر الـ Backend
curl http://localhost:3000/health

# اختبر الـ Frontend
curl http://localhost:3001

# اختبر الاتصال API
curl http://localhost:3000/api/auth/login \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test"}'
```

---

**آخر تحديث:** 17 فبراير 2026  
**الإصدار:** 6.0.0

/** @type {import('next').NextConfig} */
const nextConfig = {
    transpilePackages: ['react-markdown', 'remark-gfm', 'react-syntax-highlighter', 'lucide-react', 'framer-motion', '@monaco-editor/react'],
    async rewrites() {
        return [
            {
                source: '/api/:path*',
                destination: `${process.env.API_URL || 'http://127.0.0.1:3002'}/api/:path*`,
            },
        ];
    },
};

export default nextConfig;

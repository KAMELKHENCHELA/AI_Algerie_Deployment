'use client'

import React, { useState } from 'react'
import { Check, Zap, Rocket, ShieldCheck } from 'lucide-react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002/api';

const Pricing = () => {
    const [loading, setLoading] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)

    const handleUpgrade = async (planName: string, amount: number) => {
        setLoading(planName)
        setError(null)
        try {
            const response = await fetch(`${API_URL}/payments/checkout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ planName, amount })
            })

            if (response.ok) {
                const data = await response.json()
                if (data.checkoutUrl) {
                    window.location.href = data.checkoutUrl
                }
            } else {
                const errData = await response.json()
                setError(errData.error || 'فشلت عملية التحويل. يرجى المحاولة لاحقاً.')
            }
        } catch (error) {
            console.error('Payment failed:', error)
            setError('حدث خطأ في الاتصال بالخادم.')
        } finally {
            setLoading(null)
        }
    }

    const plans = [
        {
            name: 'Free',
            price: '0',
            icon: <Zap className="text-slate-400" />,
            features: ['3,000 استفسار شهرياً', 'المحركات الأساسية (Groq)', 'دعم اللغة العربية والأمازيغية'],
            button: 'المستوى الحالي',
            current: true,
            color: 'slate'
        },
        {
            name: 'Pro',
            price: '1500',
            icon: <Rocket className="text-emerald-400" />,
            features: ['10,000 استفسار شهرياً', 'محركات متقدمة (GPT-4/Claude)', 'تحليل ملفات غير محدود', 'دعم الأكواد البرمجية عالي الكفاءة'],
            button: 'ترقية إلى Pro',
            highlight: true,
            color: 'emerald'
        },
        {
            name: 'Enterprise',
            price: '5000',
            icon: <ShieldCheck className="text-blue-400" />,
            features: ['100,000 استفسار شهرياً', 'أولوية في معالجة الطلبات', 'لوحة تحكم خاصة للشركات', 'دعم فني مخصص 24/7'],
            button: 'ترقية إلى Enterprise',
            color: 'blue'
        }
    ]

    return (
        <div className="py-20 px-8 max-w-7xl mx-auto">
            <div className="text-center mb-16">
                <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-500">
                    اختر الخطة المناسبة لنمو مشاريعك
                </h1>
                <p className="text-slate-400 max-w-2xl mx-auto">
                    استخدم أقوى محركات الذكاء الاصطناعي في العالم مع دعم الدفع المحلي عبر البطاقة الذهبية وبنكية CIB.
                </p>
            </div>

            {error && (
                <div className="mb-8 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-center animate-shake">
                    {error}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {plans.map((plan, i) => (
                    <div
                        key={i}
                        className={`titan-glass p-8 rounded-[2.5rem] border ${plan.highlight ? 'border-emerald-500/50 scale-105' : 'border-white/5'} flex flex-col relative transition-all hover:translate-y-[-8px]`}
                    >
                        {plan.highlight && (
                            <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">
                                الأكثر طلباً
                            </span>
                        )}
                        <div className="mb-8">
                            <div className={`w-12 h-12 rounded-2xl bg-${plan.color}-400/10 flex items-center justify-center mb-4`}>
                                {plan.icon}
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                            <div className="flex items-baseline gap-1">
                                <span className="text-4xl font-bold">{plan.price}</span>
                                <span className="text-slate-400">دج / شهر</span>
                            </div>
                        </div>

                        <ul className="space-y-4 mb-8 flex-1">
                            {plan.features.map((feature, j) => (
                                <li key={j} className="flex items-center gap-3 text-sm text-slate-300">
                                    <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">
                                        <Check size={12} className="text-emerald-400" />
                                    </div>
                                    {feature}
                                </li>
                            ))}
                        </ul>

                        <button
                            onClick={() => !plan.current && handleUpgrade(plan.name, parseInt(plan.price))}
                            disabled={plan.current || loading !== null}
                            className={`w-full py-4 rounded-2xl font-bold transition-all ${plan.current
                                ? 'bg-slate-800 text-slate-500 cursor-default'
                                : plan.highlight
                                    ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/30'
                                    : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                                }`}
                        >
                            {loading === plan.name ? 'جاري التحويل...' : plan.button}
                        </button>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Pricing

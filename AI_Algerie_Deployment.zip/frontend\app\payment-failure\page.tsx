'use client'

import React from 'react'
import { XCircle, AlertCircle } from 'lucide-react'
import { useRouter } from 'next/navigation'

const PaymentFailure = () => {
    const router = useRouter()

    return (
        <div className="min-h-screen bg-[#020617] text-white flex items-center justify-center p-4">
            <div className="titan-glass p-12 rounded-[3rem] border border-red-500/30 max-w-md w-full text-center">
                <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-8">
                    <XCircle size={48} className="text-red-400" />
                </div>
                <h1 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-red-400 to-red-200">
                    عذراً، فشلت العملية
                </h1>
                <p className="text-slate-400 mb-8 leading-relaxed">
                    لم نتمكن من إتمام عملية الدفع. يرجى التحقق من بيانات البطاقة أو المحاولة مرة أخرى لاحقاً.
                </p>
                <div className="flex flex-col gap-4">
                    <button
                        onClick={() => router.push('/')}
                        className="w-full py-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold transition-all border border-white/10"
                    >
                        العودة للمتجر
                    </button>
                    <button
                        onClick={() => window.history.back()}
                        className="w-full py-4 rounded-2xl bg-red-500 hover:bg-red-600 text-white font-bold transition-all shadow-lg shadow-red-500/20 font-sans"
                    >
                        المحاولة مرة أخرى
                    </button>
                </div>
            </div>
        </div>
    )
}

export default PaymentFailure

import axios from "axios";

class SearchService {
    async search(query) {
        const apiKey = process.env.TAVILY_API_KEY;
        if (!apiKey || apiKey === "your-tavily-key-here") {
            console.warn("Tavily API key not configured, returning mock results.");
            return [
                { title: "Algeria Tech News", url: "https://example.com/1", snippet: "Latest breakthroughs in AI in Algeria." },
                { title: "Kamel Zerdoum Portfolio", url: "https://example.com/2", snippet: "Developer behind AI Algérie project." }
            ];
        }

        try {
            const response = await axios.post("https://api.tavily.com/search", {
                api_key: apiKey,
                query: query,
                search_depth: "basic",
                include_answer: false,
                include_raw_content: false,
                max_results: 5
            });

            return response.data.results;
        } catch (error) {
            console.error("Search API Error:", error);
            return [];
        }
    }

    formatResults(results) {
        if (!results || results.length === 0) return "لا توجد نتائج بحث حديثة.";
        return results.map(r => `• ${r.title}: ${r.snippet} (${r.url})`).join("\n");
    }
}

export default new SearchService();

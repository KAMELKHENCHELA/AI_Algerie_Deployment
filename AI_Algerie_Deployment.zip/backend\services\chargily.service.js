import axios from "axios";
import crypto from "crypto";

class ChargilyService {
    constructor() {
        this.apiKey = process.env.CHARGILY_API_KEY;
        this.apiSecret = process.env.CHARGILY_API_SECRET;
        this.apiUrl = "https://pay.chargily.net/test/api/v2"; // Test mode URL
    }

    async createCheckout(userId, amount, planName) {
        if (!this.apiKey || this.apiKey === "your-chargily-key-here") {
            console.warn("Chargily API key not configured, returning mock checkout URL.");
            return {
                id: "mock_" + Date.now(),
                checkout_url: "https://checkout.chargily.com/mock-pay"
            };
        }

        try {
            const response = await axios.post(`${this.apiUrl}/checkouts`, {
                amount: amount,
                currency: "dzd",
                success_url: `${process.env.FRONTEND_URL}/payment-success`,
                metadata: {
                    userId: userId.toString(),
                    planName: planName
                }
            }, {
                headers: {
                    "Authorization": `Bearer ${this.apiKey}`,
                    "Content-Type": "application/json"
                }
            });

            return response.data;
        } catch (error) {
            console.error("Chargily Checkout Error:", error);
            throw error;
        }
    }

    async verifyWebhook(signature, payload) {
        if (!this.apiSecret) return true; // Dev mode

        const computedSignature = crypto
            .createHmac("sha256", this.apiSecret)
            .update(JSON.stringify(payload))
            .digest("hex");

        return signature === computedSignature;
    }
}

export default new ChargilyService();

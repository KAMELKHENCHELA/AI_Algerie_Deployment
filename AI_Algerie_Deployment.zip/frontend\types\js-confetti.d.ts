declare module 'js-confetti' {
    export default class JSConfetti {
        addConfetti(options?: {
            emojis?: string[],
            emojiSize?: number,
            confettiNumber?: number,
            confettiColors?: string[],
        }): Promise<void>;
    }
}

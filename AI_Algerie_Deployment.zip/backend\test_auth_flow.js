import fetch from 'node-fetch';

const BASE_URL = 'http://192.168.100.3:3002/api/auth';

async function testAuthFlow() {
    const email = `test_${Date.now()}@example.com`;
    const password = "password123";

    console.log(`🚀 Starting Auth Flow Test for ${email}...`);

    try {
        // 1. Register
        console.log("1. Registering...");
        const regRes = await fetch(`${BASE_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        let token;
        if (regRes.ok) {
            const data = await regRes.json();
            token = data.token;
            console.log("✅ Registered successfully.");
        } else {
            console.log(`⚠️ Register failed: ${regRes.status}. Trying login...`);
        }

        // 2. Login (if register didn't return token or failed because user exists)
        if (!token) {
            const loginRes = await fetch(`${BASE_URL}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            if (!loginRes.ok) {
                throw new Error(`Login failed: ${loginRes.status} ${await loginRes.text()}`);
            }

            const data = await loginRes.json();
            token = data.token;
            console.log("✅ Logged in successfully.");
        }

        console.log("🔑 Token:", token.substring(0, 20) + "...");

        // 3. Test /me
        console.log("3. Testing /me endpoint...");
        const meRes = await fetch(`${BASE_URL}/me`, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (meRes.ok) {
            const user = await meRes.json();
            console.log("✅ /me verified. ID:", user.id);
        } else {
            throw new Error(`/me failed: ${meRes.status} ${await meRes.text()}`);
        }

    } catch (error) {
        console.error("❌ Auth Flow Failed:", error);
    }
}

testAuthFlow();

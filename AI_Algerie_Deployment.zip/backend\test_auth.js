import fetch from 'node-fetch';
import jwt from 'jsonwebtoken';

const SECRET_KEY = "your-secure-random-key-min-32-characters-please-change";
const API_URL = 'http://192.168.100.3:3002/api/auth/me';

async function testAuth() {
    const token = jwt.sign({ userId: 1 }, SECRET_KEY, { expiresIn: '1h' });

    console.log("🚀 Testing Auth Token:", token);

    try {
        const response = await fetch(API_URL, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            console.error(`❌ Auth Failed: ${response.status} ${response.statusText}`);
            console.log(await response.text());
        } else {
            console.log("✅ Auth Success:", await response.json());
        }

    } catch (error) {
        console.error("❌ Test Failed:", error);
    }
}

testAuth();

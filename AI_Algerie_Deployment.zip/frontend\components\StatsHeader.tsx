'use client'

import React from 'react'
import { Trophy } from 'lucide-react'

interface StatsHeaderProps {
    user: any;
}

const StatsHeader: React.FC<StatsHeaderProps> = ({ user }) => {
    return (
        <header className="flex flex-col gap-2 mb-4 bg-white/5 p-4 rounded-3xl border border-white/5">
            <div className="flex justify-between items-center px-2">
                <div className="flex items-center gap-2">
                    <div className="bg-titan-emerald/20 p-2 rounded-lg">
                        <Trophy size={18} className="text-titan-emerald" />
                    </div>
                    <div className="flex flex-col">
                        <span className="font-bold text-base tracking-wide text-white uppercase">AI Algérie v1.0</span>
                        <span className="text-xs text-titan-emerald/80 font-medium">المنصة الذكية للجزائر</span>
                    </div>
                </div>

                {user && (
                    <div className="flex items-center gap-6">
                        <div className="hidden sm:flex flex-col items-end">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Subscription</span>
                            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${user.subscriptionTier === 'free' ? 'bg-slate-800 text-slate-400' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'}`}>
                                {user.subscriptionTier?.toUpperCase()}
                            </span>
                        </div>
                        <div className="flex flex-col items-end">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">API Points</span>
                            <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-white">{user.apiLimitRemaining?.toLocaleString()}</span>
                                <div className="w-20 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                    <div
                                        className="h-full bg-titan-emerald transition-all duration-1000"
                                        style={{ width: `${Math.min((user.apiLimitRemaining / 3000) * 100, 100)}%` }}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </header>
    )
}

export default React.memo(StatsHeader)

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

class Retriever {
    async retrieveWithContext(message, options = { topK: 3 }) {
        try {
            // Basic keyword search as a placeholder for a real vector search
            // In a production environment, this would call a Vector DB like Pinecone/Weaviate
            const keywords = message.split(' ').filter(word => word.length > 3);

            const results = await prisma.message.findMany({
                where: {
                    OR: keywords.map(kw => ({
                        content: {
                            contains: kw
                        }
                    }))
                },
                take: options.topK,
                orderBy: {
                    created_at: 'desc'
                }
            });

            const context = results.map(r => `[سياق سابق]: ${r.content}`).join("\n\n");

            return {
                context,
                results: results.map(r => ({ text: r.content }))
            };
        } catch (error) {
            console.error("Retriever Error:", error);
            return { context: "", results: [] };
        }
    }
}

export default new Retriever();

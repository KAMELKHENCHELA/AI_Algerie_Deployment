
import fetch from 'node-fetch';

async function testMockAgent() {
    console.log('Testing Mock Agent API...');
    try {
        const response = await fetch('http://192.168.100.3:3002/api/mock-n8n/coding_expert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: 'How to write a binary search in JS?',
                userId: '123'
            })
        });

        if (response.ok) {
            const data = await response.json();
            console.log('✅ Mock Agent Response:', data);
        } else {
            console.error('❌ Mock Agent Request Failed:', response.status, await response.text());
        }
    } catch (error) {
        console.error('❌ Error testing mock agent:', error.message);
    }
}

testMockAgent();
